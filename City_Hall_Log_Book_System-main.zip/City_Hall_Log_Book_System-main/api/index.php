<?php

header("Content-Type: application/json");

echo json_encode('Welcome to API');