import "https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js";
import "https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js";
import 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/js/all.min.js';