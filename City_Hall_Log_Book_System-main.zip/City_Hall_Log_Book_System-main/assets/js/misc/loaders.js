export const loader = `
    <div class="loading">
        <span></span>
        <span></span>
        <span></span>
    </div>
`;
export const loader2 = `
    <i class="text-muted">
        fetching employee data<span class="dot1">.</span><span class="dot2">.</span><span class="dot3">.</span>
    </i>
`;