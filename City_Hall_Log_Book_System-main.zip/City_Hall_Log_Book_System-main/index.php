<?php

header("Location: ./page/");
