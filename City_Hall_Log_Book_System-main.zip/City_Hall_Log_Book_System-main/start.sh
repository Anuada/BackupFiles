#!/bin/bash

source ./scripts/start.sh